﻿"""
问题三模块2：高斯Copula生成关联情景
输入：mod3_q3_out.pkl
输出：mod4_q3_scenarios.pkl
"""

import pickle
import numpy as np
from scipy.linalg import cholesky
from scipy.stats import norm

print("\\\\n" + "="*60)
print("【模块4-3】高斯Copula生成关联情景")
print("="*60)

# ========== 1. 加载数据 ==========
with open("mod3_q3_out.pkl", "rb") as f:
    q3 = pickle.load(f)

crop_list = q3["crop_list"]
R = q3["R"]
lands = q3["lands"]
years = q3["years"]

# 需要从 q3 加载 Y_base, C_base, P_base, S_max_base
# 但 q3 中没有这些，需要从 mod2_out.pkl 或 mod3_out.pkl 加载
# 尝试从 mod2_out.pkl 加载（包含 df_stats）
with open("mod2_out.pkl", "rb") as f:
    d2 = pickle.load(f)

df_stats = d2["df_stats"]
df_stats.columns = [str(col).strip() for col in df_stats.columns]

# 构建基础参数
Y_base = {}
C_base = {}
P_base = {}
S_max_base = {}

# 从 df_stats 构建 Y, C, P
for _, row in df_stats.iterrows():
    j = row["作物名称"]
    ltype = row["地块类型"]
    if "亩产量/斤" in row:
        yld = float(row["亩产量/斤"])
        for i in lands:
            if q3["land_type"][i] == ltype:
                Y_base[(i, j)] = yld
    if "种植成本/(元/亩)" in row:
        cost = float(row["种植成本/(元/亩)"])
        for i in lands:
            if q3["land_type"][i] == ltype:
                C_base[(i, j)] = cost
    if "销售单价/(元/斤)" in row:
        price_str = str(row["销售单价/(元/斤)"]).strip().replace("?", "-")
        if "-" in price_str:
            price = float(price_str.split("-")[1].strip())
        else:
            price = float(price_str)
        if j not in P_base:
            P_base[j] = price

# 兜底
for j in crop_list:
    if j not in P_base:
        P_base[j] = 2.0
    for i in lands:
        Y_base.setdefault((i, j), 0.0)
        C_base.setdefault((i, j), 0.0)

# S_max_base：用2023年实际产量
S_max_base = {j: 1000.0 for j in crop_list}
df_plant = d2["df_plant_2023"]
df_plant.columns = [str(col).strip() for col in df_plant.columns]
df_plant["种植地块"] = df_plant["种植地块"].ffill()

for _, row in df_plant.iterrows():
    try:
        crop = str(row["作物名称"]).strip()
        land = str(row["种植地块"]).strip()
        area = float(row["种植面积/亩"])
        lt = q3["land_type"][land]
        season = str(row["种植季次"]).strip()
        query_lt = "普通大棚" if (lt == "智慧大棚" and season == "第一季") else lt
        stat = df_stats[
            (df_stats["作物名称"] == crop) &
            (df_stats["地块类型"] == query_lt) &
            (df_stats["种植季次"] == season)
        ]
        if not stat.empty:
            yield_kg = float(stat.iloc[0]["亩产量/斤"])
            S_max_base[crop] += area * yield_kg
    except:
        continue

print(f"? 基础参数加载完成: {len(S_max_base)}种作物")

# ========== 2. Cholesky分解 ==========
n = len(crop_list)
L = cholesky(R, lower=True)
print(f"? Cholesky分解完成")

# ========== 3. 生成关联情景 ==========
N_SCENARIOS = 200
np.random.seed(42)

scenarios = []

for s in range(N_SCENARIOS):
    U = np.random.normal(0, 1, n)
    Z = L @ U
    F = norm.cdf(Z)

    scenario = {"S_max": {}, "P": {}, "Y": {}, "C": {}, "F": F}

    for t in years:
        year_idx = t - 2024
        scenario["S_max"][t] = {}
        scenario["P"][t] = {}
        scenario["Y"][t] = {}
        scenario["C"][t] = {}

        for idx, j in enumerate(crop_list):
            f_val = F[idx]

            # 销量上限
            base_s = S_max_base.get(j, 1000)
            if j in ['小麦', '玉米']:
                growth = 0.05 + 0.05 * f_val
                s_val = base_s * (1 + growth) ** year_idx
            else:
                change = -0.05 + 0.10 * f_val
                s_val = base_s * (1 + change) ** year_idx
            scenario["S_max"][t][j] = max(s_val, 100)

            # 销售价格
            base_p = P_base.get(j, 2.0)
            if j in ['小麦', '玉米', '水稻']:
                p_val = base_p
            elif j in ['黄豆', '黑豆', '红豆', '绿豆', '爬豆', '豇豆', '刀豆', '芸豆']:
                p_val = base_p * (1.05 ** year_idx) * (1 + 0.1 * f_val)
            elif j in ['榆黄菇', '香菇', '白灵菇', '羊肚菌']:
                decline = 0.01 + 0.04 * (1 - f_val)
                p_val = base_p * (1 - decline) ** year_idx
            else:
                p_val = base_p * (1.05 ** year_idx) * (1 + 0.1 * f_val)
            scenario["P"][t][j] = max(p_val, 0.5)

            # 亩产量和成本（按地块）
            for i in lands:
                base_y = Y_base.get((i, j), 0)
                scenario["Y"][t][(i, j)] = base_y * (0.9 + 0.2 * f_val)

                base_c = C_base.get((i, j), 0)
                c_val = min(base_c * (1.05 ** year_idx) * (1 + 0.06 * f_val), base_c * 1.30)
                scenario["C"][t][(i, j)] = c_val

    scenarios.append(scenario)

print(f"? 生成 {N_SCENARIOS} 个关联情景")

# ========== 4. 保存 ==========
with open("mod4_q3_scenarios.pkl", "wb") as f:
    pickle.dump({
        "scenarios": scenarios,
        "N_SCENARIOS": N_SCENARIOS,
        "R": R,
        "crop_list": crop_list,
        "lands": lands,
        "years": years,
    }, f)

print("? 模块4-3完成，输出 mod4_q3_scenarios.pkl")