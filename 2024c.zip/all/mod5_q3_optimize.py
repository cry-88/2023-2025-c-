﻿"""
问题三模块3：均值-方差优化求解
输入：mod4_q3_scenarios.pkl, mod3_q3_out.pkl
输出：result3.xlsx, q3_optimization_report.xlsx
"""

import pickle
import pandas as pd
import numpy as np
from pulp import *
import warnings
warnings.filterwarnings('ignore')

print("\\n" + "="*60)
print("【模块5-3】问题三：均值-方差优化求解")
print("="*60)

# ========== 1. 加载情景 ==========
with open("mod4_q3_scenarios.pkl", "rb") as f:
    data = pickle.load(f)

scenarios = data["scenarios"]
N_SCENARIOS = data["N_SCENARIOS"]

# ========== 2. 加载基础数据 ==========
with open("mod3_q3_out.pkl", "rb") as f:
    q3 = pickle.load(f)

# 从 q3 加载所有变量（全部存在，因为 mod3_q3_params 已保存完整）
lands = q3["lands"]
land_area = q3["land_area"]
land_type = q3["land_type"]
flat_lands = q3["flat_lands"]
water_lands = q3["water_lands"]
normal_greenhouse = q3["normal_greenhouse"]
crop_list = q3["crop_list"]
bean_crops = q3["bean_crops"]
mushroom_crops = q3["mushroom_crops"]
autumn_veg = q3["autumn_veg"]
rice_crops = q3["rice_crops"]
first_season_veg = q3["first_season_veg"]
years = q3["years"]
seasons = q3["seasons"]
Allow = q3["Allow"]
Hist = q3["Hist"]

print(f"✅ 加载完成: {len(lands)}块地, {len(crop_list)}种作物, {N_SCENARIOS}个情景")

# ========== 3. 构建优化模型 ==========
def build_mean_var_model(scenarios):
    """基于平均情景的线性规划模型"""
    model = LpProblem("Q3_MeanVar", LpMaximize)

    valid_x_keys = []
    valid_z_s_keys = []
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s == 2:
                    continue
                for j in crop_list:
                    if Allow[(i, s, j)] == 1:
                        valid_x_keys.append((i, t, s, j))
                        valid_z_s_keys.append((i, t, s, j))
    valid_z_y_keys = [(i, t, j) for i in lands for t in years for j in crop_list]

    x = LpVariable.dicts("x", valid_x_keys, lowBound=0, cat='Continuous')
    z_season = LpVariable.dicts("z_s", valid_z_s_keys, cat='Binary')
    z_year = LpVariable.dicts("z_y", valid_z_y_keys, cat='Binary')

    # 计算平均情景参数
    avg_S_max = {}
    avg_P = {}
    avg_Y = {}
    avg_C = {}

    for t in years:
        avg_S_max[t] = {}
        avg_P[t] = {}
        avg_Y[t] = {}
        avg_C[t] = {}
        for j in crop_list:
            avg_S_max[t][j] = np.mean([s["S_max"][t][j] for s in scenarios])
            avg_P[t][j] = np.mean([s["P"][t][j] for s in scenarios])
        for i in lands:
            for j in crop_list:
                avg_Y[t][(i, j)] = np.mean([s["Y"][t][(i, j)] for s in scenarios])
                avg_C[t][(i, j)] = np.mean([s["C"][t][(i, j)] for s in scenarios])

    print("✅ 平均情景参数计算完成")

    # ----- 约束 -----
    # 面积上限
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s == 2:
                    continue
                keys_this = [(i, t, s, j) for j in crop_list if (i, t, s, j) in x]
                if keys_this:
                    model += lpSum(x[k] for k in keys_this) <= land_area[i]

    # 最小0.3亩
    for key in valid_x_keys:
        i, t, s, j = key
        model += x[key] >= 0.3 * z_season[(i, t, s, j)]

    # 季转年
    for i in lands:
        for t in years:
            for j in crop_list:
                z_s_list = []
                for s in seasons:
                    if (i, t, s, j) in z_season:
                        z_s_list.append(z_season[(i, t, s, j)])
                if z_s_list:
                    for zs in z_s_list:
                        model += z_year[(i, t, j)] >= zs
                    model += z_year[(i, t, j)] <= lpSum(z_s_list)
                else:
                    model += z_year[(i, t, j)] == 0

    # 重茬
    for i in lands:
        for s in seasons:
            for j in crop_list:
                if Hist[(i, s, j)] == 1 and (i, 2024, s, j) in x:
                    model += x[(i, 2024, s, j)] == 0
    for i in lands:
        for s in seasons:
            for j in crop_list:
                for t in range(2025, 2031):
                    if (i, t, s, j) in z_season and (i, t-1, s, j) in z_season:
                        model += z_season[(i, t, s, j)] + z_season[(i, t-1, s, j)] <= 1

    # 跨季重茬
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s == 2:
                    continue
                for j in crop_list:
                    if t == 2024 and s == 1:
                        if (i, 2024, 1, j) in z_season and (i, 2023, 2, j) in z_season:
                            model += z_season[(i, 2024, 1, j)] + z_season[(i, 2023, 2, j)] <= 1
                    elif t > 2024:
                        prev_s = 2 if s == 1 else 1
                        prev_t = t - 1 if s == 1 else t
                        if (i, t, s, j) in z_season and (i, prev_t, prev_s, j) in z_season:
                            model += z_season[(i, t, s, j)] + z_season[(i, prev_t, prev_s, j)] <= 1

    # 连续三年豆类
    for i in lands:
        for t_start in range(2024, 2029):
            model += lpSum(z_year[(i, t, j)] for t in range(t_start, t_start+3) for j in bean_crops) >= 1

    # 水浇地
    for i in water_lands:
        for t in years:
            z_rice = lpSum(z_year[(i, t, j)] for j in rice_crops)
            z_veg = lpSum(z_season[(i, t, 1, j)] for j in first_season_veg if (i, t, 1, j) in z_season)
            model += z_rice + z_veg <= 1
            veg_area = lpSum(x[(i, t, 1, j)] for j in first_season_veg if (i, t, 1, j) in x)
            autumn_area = lpSum(x[(i, t, 2, j)] for j in autumn_veg if (i, t, 2, j) in x)
            model += autumn_area >= veg_area
            model += lpSum(z_season[(i, t, 2, j)] for j in autumn_veg if (i, t, 2, j) in z_season) <= 1

    # 普通大棚第二季满种
    for i in normal_greenhouse:
        for t in years:
            mushroom_area = lpSum(x[(i, t, 2, j)] for j in mushroom_crops if (i, t, 2, j) in x)
            model += mushroom_area >= 0.8 * land_area[i]

    # 产量拆分
    u = LpVariable.dicts("u", [(t, j) for t in years for j in crop_list], lowBound=0)
    v = LpVariable.dicts("v", [(t, j) for t in years for j in crop_list], lowBound=0)

    for t in years:
        for j in crop_list:
            y_terms = []
            for i in lands:
                for s in seasons:
                    if (i, t, s, j) in x:
                        y_terms.append(x[(i, t, s, j)] * avg_Y[t].get((i, j), 0))
            if y_terms:
                total_y = lpSum(y_terms)
                model += u[(t, j)] + v[(t, j)] == total_y
                model += u[(t, j)] <= avg_S_max[t].get(j, 1000)
            else:
                model += u[(t, j)] == 0
                model += v[(t, j)] == 0

    # 目标函数
    revenue = lpSum(avg_P[t].get(j, 2.0) * u[(t, j)] for t in years for j in crop_list)
    revenue += lpSum(0.5 * avg_P[t].get(j, 2.0) * v[(t, j)] for t in years for j in crop_list)
    cost = lpSum(avg_C[t].get((i, j), 0) * x[(i, t, s, j)] for (i, t, s, j) in valid_x_keys)

    model += revenue - cost

    return model, x, z_season, z_year, u, v


# ========== 4. 求解 ==========
print("\\n开始求解均值-方差优化模型...")
model, x, zs, zy, u, v = build_mean_var_model(scenarios)

solver = PULP_CBC_CMD(msg=False, timeLimit=1200)
model.solve(solver)

print(f"求解状态: {LpStatus[model.status]}")
print(f"平均情景下7年总利润: {model.objective.value():.2f} 元")


# ========== 5. 提取结果 ==========
def extract_results(model, x_var_dict):
    var_name_to_val = {v.name: v.varValue for v in model.variables() if v.varValue is not None}
    rec = []
    for key_tuple in x_var_dict:
        var_obj = x_var_dict[key_tuple]
        val = var_name_to_val.get(var_obj.name, 0.0)
        if val > 0.001:
            i, t, s, j = key_tuple
            rec.append({"地块名": i, "年份": t, "季次": s, "作物": j, "种植面积": round(val, 2)})
    return pd.DataFrame(rec)


def format_export(df, output_name):
    all_rows = []
    for i in lands:
        for s in seasons:
            if i in flat_lands and s == 2:
                continue
            all_rows.append(f"{i}_{'第一季' if s==1 else '第二季'}")
    with pd.ExcelWriter(output_name) as writer:
        for year in years:
            dfy = df[df["年份"] == year].copy()
            dfy["行标识"] = dfy.apply(lambda r: f"{r['地块名']}_{'第一季' if r['季次']==1 else '第二季'}", axis=1)
            if dfy.empty:
                pivot = pd.DataFrame(0, index=all_rows, columns=crop_list)
            else:
                pivot = dfy.pivot_table(index="行标识", columns="作物", values="种植面积", fill_value=0, aggfunc="sum")
                for c in crop_list:
                    if c not in pivot.columns:
                        pivot[c] = 0
                pivot = pivot.reindex(all_rows, fill_value=0)[crop_list]
            pivot.index.name = "季次"
            pivot.to_excel(writer, sheet_name=str(year))


df_q3 = extract_results(model, x)
format_export(df_q3, "result3.xlsx")
print("✅ result3.xlsx 已生成")


# ========== 6. 情景仿真评估 ==========
print("\\n开始情景仿真评估（N=%d）..." % N_SCENARIOS)

plant_plan = {}
for _, row in df_q3.iterrows():
    key = (row["年份"], row["地块名"], row["季次"], row["作物"])
    plant_plan[key] = row["种植面积"]

profits = []
for s in scenarios:
    total_profit = 0
    for t in years:
        for i in lands:
            for s_season in seasons:
                if i in flat_lands and s_season == 2:
                    continue
                for j in crop_list:
                    area = plant_plan.get((t, i, s_season, j), 0)
                    if area <= 0:
                        continue
                    yld = s["Y"][t].get((i, j), 0)
                    cost = s["C"][t].get((i, j), 0)
                    price = s["P"][t].get(j, 2.0)
                    smax = s["S_max"][t].get(j, 1000)

                    yield_kg = area * yld
                    u_sim = min(yield_kg, smax)
                    v_sim = max(yield_kg - smax, 0)
                    revenue = price * u_sim + 0.5 * price * v_sim
                    total_profit += revenue - area * cost
    profits.append(total_profit)

profits = np.array(profits)
mean_profit = np.mean(profits)
std_profit = np.std(profits)
var_5 = np.percentile(profits, 5)
cvar_5 = np.mean(profits[profits <= var_5])

print("\\n【问题三：均值-方差评估结果】")
print(f"  期望利润（均值）: {mean_profit:.2f} 元")
print(f"  标准差: {std_profit:.2f} 元")
print(f"  5%分位数(VaR): {var_5:.2f} 元")
print(f"  CVaR_5%: {cvar_5:.2f} 元")
print(f"  均值-标准差比: {mean_profit/std_profit:.2f}")

report = pd.DataFrame({
    "指标": ["期望利润", "标准差", "5%分位数(VaR)", "CVaR_5%", "均值/标准差比"],
    "数值": [mean_profit, std_profit, var_5, cvar_5, mean_profit/std_profit]
})
report.to_excel("q3_optimization_report.xlsx", index=False)

print("\\n✅ q3_optimization_report.xlsx 已生成")
print("="*60)
print("【模块5-3】完成！")