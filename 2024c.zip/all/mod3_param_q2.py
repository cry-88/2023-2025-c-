﻿"""
问题二专用：生成时间维度的参数（修复版）
修复内容：
  1. 补全 Y_by_year 完整存储（按地块+作物+年份）
  2. 删除 DEMAND_RATIO=0.7 双重压缩
  3. 成本增加上限保护（累计上浮30%封顶）
输入：mod2_out.pkl
输出：mod3_q2_out.pkl
"""

import pandas as pd
import pickle

print("\\n" + "="*60)
print("【模块3-2】问题二：时间维度参数生成（修复版）")
print("="*60)

with open("mod2_out.pkl", "rb") as f:
    d = pickle.load(f)

crop_list = d["crop_list"]
lands = d["lands"]
land_type = d["land_type"]
land_area = d["land_area"]
df_plant_2023 = d["df_plant_2023"]
df_stats = d["df_stats"]
years = d["years"]
seasons = d["seasons"]

# ----- 1. 清洗列名 -----
df_plant_2023.columns = [str(col).strip() for col in df_plant_2023.columns]
df_stats.columns = [str(col).strip() for col in df_stats.columns]

for col in ["作物名称", "地块类型", "种植季次"]:
    if col in df_stats.columns:
        df_stats[col] = df_stats[col].astype(str).str.strip()

# ----- 2. 构造作物分类 -----
bean_crops = ['黄豆', '黑豆', '红豆', '绿豆', '爬豆', '豇豆', '刀豆', '芸豆']
mushroom_crops = ['榆黄菇', '香菇', '白灵菇', '羊肚菌']
autumn_veg = ['大白菜', '白萝卜', '红萝卜']
rice_crops = ['水稻']
grain_crops = ['小麦', '玉米', '谷子', '高粱', '黍子', '荞麦', '南瓜', '红薯', '莜麦', '大麦']
vegetable_crops = [c for c in crop_list if c not in grain_crops and c not in rice_crops and c not in mushroom_crops and c not in bean_crops]

# ----- 3. 构建基础 Y、C、P -----
def parse_price(s):
    s = str(s).strip().replace("‑", "-")
    if "-" in s:
        return float(s.split("-")[1].strip())
    return float(s)

Y_base = {}
C_base = {}
P_base = {}

for _, row in df_stats.iterrows():
    j = row["作物名称"]
    ltype = row["地块类型"]
    yld = float(row["亩产量/斤"])
    cost = float(row["种植成本/(元/亩)"])
    price_high = parse_price(row["销售单价/(元/斤)"])

    for i in lands:
        if land_type[i] == ltype:
            Y_base[(i, j)] = yld
            C_base[(i, j)] = cost
    if j not in P_base:
        P_base[j] = price_high

# 兜底
for j in crop_list:
    if j not in P_base:
        P_base[j] = 2.0
        for i in lands:
            Y_base.setdefault((i, j), 0.0)
            C_base.setdefault((i, j), 0.0)

# ----- 4. 计算基础 S_max（2023年总产量） -----
df_plant_2023["种植地块"] = df_plant_2023["种植地块"].ffill()
S_max_base = {j: 0.0 for j in crop_list}

for _, row in df_plant_2023.iterrows():
    try:
        crop_name = str(row["作物名称"]).strip()
        land_name = str(row["种植地块"]).strip()
        plant_season = str(row["种植季次"]).strip()
        plant_area = float(row["种植面积/亩"])

        lt = land_type[land_name]
        query_lt = "普通大棚" if (lt == "智慧大棚" and plant_season == "第一季") else lt

        stat_info = df_stats[
            (df_stats["作物名称"] == crop_name) &
            (df_stats["地块类型"] == query_lt) &
            (df_stats["种植季次"] == plant_season)
        ]
        if stat_info.empty:
            continue
        yy = float(stat_info.iloc[0]["亩产量/斤"])
        S_max_base[crop_name] += plant_area * yy
    except:
        continue

# ----- 5. 构建时间维度参数（修复版） -----
S_max_by_year = {}
Y_by_year = {}
C_by_year = {}
P_by_year = {}

# 成本上涨上限：累计上浮30%后封顶
MAX_COST_INCREASE = 1.30

for t in years:
    year_idx = t - 2024
    S_max_by_year[t] = {}
    Y_by_year[t] = {}
    C_by_year[t] = {}
    P_by_year[t] = {}

    # ----- 5a. 销量上限（仅用增长率区间，不再叠加0.7系数） -----
    for j in crop_list:
        base = S_max_base.get(j, 1000)
        if j in ['小麦', '玉米']:
            growth = 0.05  # 最坏情景：最低增长率5%
        else:
            growth = -0.05  # 最坏情景：其他作物下滑5%
        S_max_by_year[t][j] = base * (1 + growth) ** year_idx

    # ----- 5b. 亩产量（最坏：-10%）-----
    for i in lands:
        for j in crop_list:
            Y_by_year[t][(i, j)] = Y_base.get((i, j), 0) * 0.9

    # ----- 5c. 种植成本（最坏：年增长5%，但设上限） -----
    for i in lands:
        for j in crop_list:
            base_c = C_base.get((i, j), 0)
            raw_cost = base_c * (1.05 ** year_idx)
            C_by_year[t][(i, j)] = min(raw_cost, base_c * MAX_COST_INCREASE)

    # ----- 5d. 销售价格（最坏情景） -----
    for j in crop_list:
        base_p = P_base.get(j, 2.0)
        if j in grain_crops or j in rice_crops:
            P_by_year[t][j] = base_p  # 粮食类稳定
        elif j in vegetable_crops or j in bean_crops:
            P_by_year[t][j] = base_p * (1.05 ** year_idx)  # 蔬菜年增5%
        elif j in mushroom_crops:
            P_by_year[t][j] = base_p * (0.95 ** year_idx)  # 食用菌年降5%
        else:
            P_by_year[t][j] = base_p

print(f"✅ 时间维度参数生成完成，年份范围：{min(years)} ~ {max(years)}")
print(f"✅ 成本上涨上限：{MAX_COST_INCREASE*100:.0f}%")

# ----- 6. 保存 -----
out_q2 = {
    "lands": lands,
    "land_area": land_area,
    "land_type": land_type,
    "flat_lands": d["flat_lands"],
    "water_lands": d["water_lands"],
    "normal_greenhouse": d["normal_greenhouse"],
    "smart_greenhouse": d["smart_greenhouse"],
    "crop_list": crop_list,
    "bean_crops": bean_crops,
    "autumn_veg": autumn_veg,
    "first_season_veg": d["first_season_veg"],
    "rice_crops": rice_crops,
    "mushroom_crops": mushroom_crops,
    "grain_crops": grain_crops,
    "vegetable_crops": vegetable_crops,
    "years": years,
    "seasons": seasons,
    "Allow": d["Allow"],
    "Hist": d["Hist"],
    "Y_base": Y_base,
    "C_base": C_base,
    "P_base": P_base,
    "S_max_base": S_max_base,
    "S_max_by_year": S_max_by_year,
    "Y_by_year": Y_by_year,
    "C_by_year": C_by_year,
    "P_by_year": P_by_year
}

with open("mod3_q2_out.pkl", "wb") as f:
    pickle.dump(out_q2, f)

print("✅ 模块3-2完成，输出 mod3_q2_out.pkl")