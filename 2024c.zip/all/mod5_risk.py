﻿"""
问题二：情景模拟风险评估（固定鲁棒方案）
输入：mod3_q2_out.pkl, result2.xlsx
输出：risk_report.xlsx, risk_distribution.png
功能：在200个随机情景下评估鲁棒方案的利润分布
"""

import pickle
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# ===== 修复中文显示问题 =====
# 设置中文字体（Windows 常用字体）
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示为方框

print("\\n" + "="*60)
print("【模块5】情景模拟风险评估（修复版）")
print("="*60)

with open("mod3_q2_out.pkl", "rb") as f:
    d = pickle.load(f)

lands = d["lands"]
flat_lands = d["flat_lands"]
crop_list = d["crop_list"]
years = d["years"]
seasons = d["seasons"]
Y_base = d["Y_base"]
C_base = d["C_base"]
P_base = d["P_base"]
S_max_base = d["S_max_base"]
land_type = d["land_type"]

# ----- 1. 读取鲁棒方案 -----
df_plan = pd.read_excel("result2.xlsx", sheet_name=None)

plant_plan = {}
for year, df_sheet in df_plan.items():
    y = int(year)
    for _, row in df_sheet.iterrows():
        for j in crop_list:
            area = row.get(j, 0)
            if area > 0:
                land_name, season_str = row["季次"].split("_")
                s = 1 if season_str == "第一季" else 2
                plant_plan[(y, land_name, s, j)] = area

print(f"✅ 加载种植方案，共 {len(plant_plan)} 条种植记录")

# ----- 2. 作物分类（用于价格/销量判断） -----
grain_crops = ['小麦', '玉米', '谷子', '高粱', '黍子', '荞麦', '南瓜', '红薯', '莜麦', '大麦']
rice_crops = ['水稻']
bean_crops = ['黄豆', '黑豆', '红豆', '绿豆', '爬豆', '豇豆', '刀豆', '芸豆']
mushroom_crops = ['榆黄菇', '香菇', '白灵菇', '羊肚菌']
vegetable_crops = [c for c in crop_list if c not in grain_crops and c not in rice_crops and c not in mushroom_crops and c not in bean_crops]

# ----- 3. 情景模拟 -----
N_SCENARIOS = 200
profits = []
np.random.seed(42)

for s in range(N_SCENARIOS):
    total_profit = 0
    for t in years:
        year_idx = t - 2024
        for i in lands:
            for s_season in seasons:
                if i in flat_lands and s_season == 2:
                    continue
                for j in crop_list:
                    area = plant_plan.get((t, i, s_season, j), 0)
                    if area <= 0:
                        continue

                    # --- 随机参数 ---
                    # 亩产量：±10%均匀分布
                    yld = Y_base.get((i, j), 0) * np.random.uniform(0.9, 1.1)

                    # 种植成本：年增长5% + 小波动，有上限保护
                    base_c = C_base.get((i, j), 0)
                    raw_cost = base_c * (1.05 ** year_idx) * np.random.uniform(0.97, 1.03)
                    cost = min(raw_cost, base_c * 1.30)

                    # 销售价格
                    base_p = P_base.get(j, 2.0)
                    if j in grain_crops or j in rice_crops:
                        price = base_p
                    elif j in vegetable_crops or j in bean_crops:
                        price = base_p * (1.05 ** year_idx) * np.random.uniform(0.97, 1.03)
                    elif j in mushroom_crops:
                        decline = np.random.uniform(0.01, 0.05)
                        price = base_p * (1 - decline) ** year_idx * np.random.uniform(0.97, 1.03)
                    else:
                        price = base_p

                    # 销量上限：按增长率区间随机
                    base_smax = S_max_base.get(j, 1000)
                    if j in ['小麦', '玉米']:
                        growth = np.random.uniform(0.05, 0.10)
                        smax = base_smax * (1 + growth) ** year_idx
                    else:
                        change = np.random.uniform(-0.05, 0.05)
                        smax = base_smax * (1 + change) ** year_idx

                    # 确保销量上限为正
                    smax = max(smax, 100)

                    yield_kg = area * yld
                    u_sim = min(yield_kg, smax)
                    v_sim = max(yield_kg - smax, 0)

                    revenue = price * u_sim + 0.5 * price * v_sim
                    total_profit += revenue - area * cost

    profits.append(total_profit)

# ----- 4. 风险统计 -----
profits = np.array(profits)
stats = {
    "均值": np.mean(profits),
    "标准差": np.std(profits),
    "最小值": np.min(profits),
    "5%分位数(VaR)": np.percentile(profits, 5),
    "25%分位数": np.percentile(profits, 25),
    "中位数": np.percentile(profits, 50),
    "75%分位数": np.percentile(profits, 75),
    "最大值": np.max(profits)
}

print("\\n【风险评估结果（%d个情景）】" % N_SCENARIOS)
for k, v in stats.items():
    print(f"  {k}: {v:.2f} 元")

# ----- 5. 保存报告 -----
df_stats = pd.DataFrame([stats]).T
df_stats.columns = ["数值"]
df_stats.to_excel("risk_report.xlsx", header=["数值"])

# ----- 6. 绘图 -----
plt.figure(figsize=(10, 6))
plt.hist(profits, bins=30, edgecolor='black', alpha=0.7, color='steelblue')
plt.axvline(stats["均值"], color='red', linestyle='--', linewidth=2, label=f"均值: {stats['均值']:.0f}")
plt.axvline(stats["5%分位数(VaR)"], color='orange', linestyle='--', linewidth=2, label=f"VaR_5%: {stats['5%分位数(VaR)']:.0f}")
plt.xlabel("7年总利润（元）")
plt.ylabel("频次")
plt.title("鲁棒种植方案的利润分布（200个随机情景）")
plt.legend()
plt.grid(alpha=0.3)
plt.savefig("risk_distribution.png", dpi=300)
plt.show()

print("\\n✅ risk_report.xlsx 已生成")
print("✅ risk_distribution.png 已生成")
print("="*60)
print("【模块5】完成！")