﻿import pandas as pd
import pickle

# 调试开关：True打印详细调试日志；False只打印关键信息
DEBUG = False

# 模型参数
Y = 0
r = 0
C = 0
P = 0


def clean_df_columns(df):
    """清洗DataFrame列名：去除首尾空白字符"""
    df.columns = [str(col).strip() for col in df.columns]
    return df


def clean_triple_dict(dict_in):
    """清洗 (地块,季次,作物) 三元组字典，作物名去除首尾空格"""
    dict_out = {}
    for (i, s, j), val in dict_in.items():
        j_new = str(j).strip()
        dict_out[(i, s, j_new)] = val
    return dict_out


def main():
    with open("mod2_out.pkl", "rb") as f:
        mod2_data = pickle.load(f)

    crop_list = mod2_data["crop_list"]
    lands = mod2_data["lands"]
    land_type = mod2_data["land_type"]
    land_area = mod2_data["land_area"]   # 每个地块的总亩数！！

    df_plant_2023 = mod2_data["df_plant_2023"]
    df_stats = mod2_data["df_stats"]
    df_plant_2023 = clean_df_columns(df_plant_2023)
    df_stats = clean_df_columns(df_stats)

    # ========== 关键修复1：向前填充种植地块，处理第二季地块为空 ==========
    df_plant_2023["种植地块"] = df_plant_2023["种植地块"].ffill()

    # 校验关键列是否存在
    required_cols_plant = ["作物名称", "种植地块", "种植季次", "种植面积/亩"] # 增加种植面积/亩
    for col in required_cols_plant:
        if col not in df_plant_2023.columns:
            raise KeyError(f"df_plant_2023 缺失必要列：{col}")

    required_cols_stats = ["作物名称", "地块类型", "种植季次", "亩产量/斤"]
    for col in required_cols_stats:
        if col not in df_stats.columns:
            raise KeyError(f"df_stats 缺失必要列：{col}")

    # ========== 关键修复3：df_stats字符串字段统一去除首尾空格，解决脏空格 ==========
    str_cols = ["作物名称", "地块类型", "种植季次"]
    for col in str_cols:
        df_stats[col] = df_stats[col].astype(str).str.strip()

    if DEBUG:
        print("df_plant_2023 columns:", repr(df_plant_2023.columns.tolist()))

    # ----------------【重点】全部作物列表统一去空格----------------
    crop_list_clean = [c.strip() for c in crop_list]
    bean_crops_clean = [c.strip() for c in mod2_data["bean_crops"]]
    autumn_veg_clean = [c.strip() for c in mod2_data["autumn_veg"]]
    first_season_veg_clean = [c.strip() for c in mod2_data["first_season_veg"]]
    rice_crops_clean = [c.strip() for c in mod2_data["rice_crops"]]

    S_max = {j: 0.0 for j in crop_list_clean}

    print("\n===== 开始计算S_max市场预期销量上限 =====")
    if DEBUG:
        print(f"crop_list_clean = {crop_list_clean}")

    for idx, row in df_plant_2023.iterrows():
        try:
            if DEBUG:
                print(f"\n--- 当前表格行号: {idx} ---")
            crop_name_raw = row.get("作物名称")
            land_name_raw = row.get("种植地块")
            season_raw = row.get("种植季次")
            real_plant_area_raw = row.get("种植面积/亩") # ✅读取表格真实播种面积

            if DEBUG:
                print(f"原始值 | 作物名称:{crop_name_raw}, 种植地块:{land_name_raw}, 种植季次:{season_raw}, 实际播种面积:{real_plant_area_raw}")

            # 1.校验作物名称
            if pd.isna(crop_name_raw):
                print(f"⚠️ 警告：第{idx}行【作物名称】为空，跳过该行")
                continue
            crop_name = str(crop_name_raw).strip()

            if pd.isna(land_name_raw):
                print(f"⚠️警告：第{idx}行经过ffill后地块依然为空，跳过")
                continue
            land_name = str(land_name_raw).strip()
            if land_name == "":
                print(f"⚠️警告：第{idx}行地块为空字符串，跳过")
                continue

            # 校验种植季次
            if pd.isna(season_raw):
                print(f"⚠️警告：第{idx}行【种植季次】为空，跳过该行")
                continue
            plant_season = str(season_raw).strip()

            # ✅【重大修复】不再取land_area[land_name]整块地面积，读取表格真实播种面积
            if pd.isna(real_plant_area_raw):
                print(f"⚠️警告：第{idx}行种植面积为空，跳过")
                continue
            plant_area = float(real_plant_area_raw)
            if DEBUG:
                print(f"地块[{land_name}]，该行实际播种面积 = {plant_area} 亩")

            # 获取地块类型
            lt = land_type[land_name]
            lt = str(lt).strip()

            # ========== 业务注释规则：智慧大棚第一季等价普通大棚第一季 ==========
            query_lt = lt
            if lt == "智慧大棚" and plant_season == "第一季":
                query_lt = "普通大棚"
                if DEBUG:
                    print(f"📌业务规则触发：智慧大棚第一季 → 使用普通大棚参数查询")

            if DEBUG:
                print(f"land_name[{land_name}] → 原始地块类型lt={lt}, 查询使用地块类型query_lt={query_lt}")

            # ==========关键修复2：三条件联合筛选：作物名称 + 查询地块类型 + 种植季次 ==========
            stat_info = df_stats[
                (df_stats["作物名称"] == crop_name)
                & (df_stats["地块类型"] == query_lt)
                & (df_stats["种植季次"] == plant_season)
            ]

            if DEBUG:
                print(f"stat_info筛选结果行数:{len(stat_info)}")

            if stat_info.empty:
                print(f"⚠️警告：df_stats找不到【作物={crop_name}，地块类型={query_lt}，种植季次={plant_season}】匹配记录")
                continue

            stat_row = stat_info.iloc[0]
            if DEBUG:
                print("stat_info行内容:\n", stat_row.to_dict())

            yy_raw = stat_row["亩产量/斤"]
            yy = float(yy_raw)

            add_val = plant_area * yy
            S_max[crop_name] += add_val
            if DEBUG:
                print(f"✅累加：作物[{crop_name}] 面积{plant_area}亩 *亩产量{yy}斤 = {add_val}斤, 当前S_max[{crop_name}]={S_max[crop_name]}斤")

        except Exception as e:
            print(f"⚠️ 第{idx}行处理异常，跳过，异常信息：{str(e)}")
            continue

    print("\n===== S_max计算完成（原始2023总产量） =====")
    print(f"S_max字典长度:{len(S_max)}")
    for k, v in S_max.items():
        print(f"{k} : {v:.2f}")

    # =====================新增市场需求缩放系数====================
    market_demand_ratio = 0.70   # 市场需求为去年总产量70%，可0.6~0.8调参
    print(f"\n===== 应用市场需求系数 ratio={market_demand_ratio}  =====")
    for j in S_max:
        S_max[j] = S_max[j] * market_demand_ratio

    print("\n===== 缩放后S_max（模型销量上限） =====")
    for k, v in S_max.items():
        print(f"{k} : {v:.2f}")
    # ============================================================

    # --------【重点】清洗Allow、Hist三元组字典（把key里面作物名去空格）--------
    Allow_clean = clean_triple_dict(mod2_data["Allow"])
    Hist_clean = clean_triple_dict(mod2_data["Hist"])

    print("mod2_data所有keys:", list(mod2_data.keys()))

    out3 = {
        'lands': mod2_data["lands"],
        'land_area': mod2_data["land_area"],
        'land_type': mod2_data["land_type"],
        'flat_lands': mod2_data["flat_lands"],
        'water_lands': mod2_data["water_lands"],
        'crop_list': crop_list_clean,
        'bean_crops': bean_crops_clean,
        'autumn_veg': autumn_veg_clean,
        'first_season_veg': first_season_veg_clean,
        'rice_crops': rice_crops_clean,
        'years': mod2_data["years"],
        'seasons': mod2_data["seasons"],
        'Allow': Allow_clean,
        'Hist': Hist_clean,
        'df_stats': df_stats,   # df_stats内部字符串列已经strip
        'S_max': S_max
    }

    with open("mod3_out.pkl", "wb") as f:
        pickle.dump(out3, f)

    print("✅模块3完成，输出 mod3_out.pkl")

if __name__ == "__main__":
    main()