﻿"""
问题二：鲁棒优化主求解（最坏情景）- 修复版
修复内容：
  1. 使用 Y_by_year 字典，不再硬编码 0.9
  2. 使用修复后的 S_max_by_year（无双重压缩）
  3. 成本使用 C_by_year（含上限保护）
输入：mod3_q2_out.pkl
输出：result2.xlsx
"""

import pickle
import pandas as pd
from pulp import *
import warnings
warnings.filterwarnings('ignore')

print("\\n" + "="*60)
print("【模块4-2】问题二：鲁棒优化求解（修复版）")
print("="*60)

with open("mod3_q2_out.pkl", "rb") as f:
    d = pickle.load(f)

lands = d["lands"]
land_area = d["land_area"]
land_type = d["land_type"]
flat_lands = d["flat_lands"]
water_lands = d["water_lands"]
crop_list = d["crop_list"]
bean_crops = d["bean_crops"]
autumn_veg = d["autumn_veg"]
first_season_veg = d["first_season_veg"]
rice_crops = d["rice_crops"]
mushroom_crops = d["mushroom_crops"]
years = d["years"]
seasons = d["seasons"]
Allow = d["Allow"]
Hist = d["Hist"]
normal_greenhouse = [i for i in lands if land_type[i] == "普通大棚"]

S_max_by_year = d["S_max_by_year"]
Y_by_year = d["Y_by_year"]
C_by_year = d["C_by_year"]
P_by_year = d["P_by_year"]

print(f"普通大棚: {len(normal_greenhouse)}个")


def build_robust_model():
    model = LpProblem("Q2_Robust", LpMaximize)

    valid_x_keys = []
    valid_z_s_keys = []
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s == 2:
                    continue
                for j in crop_list:
                    if Allow[(i, s, j)] == 1:
                        valid_x_keys.append((i, t, s, j))
                        valid_z_s_keys.append((i, t, s, j))
    valid_z_y_keys = [(i, t, j) for i in lands for t in years for j in crop_list]

    print(f"有效x变量数: {len(valid_x_keys)}")

    x = LpVariable.dicts("x", valid_x_keys, lowBound=0, cat='Continuous')
    z_season = LpVariable.dicts("z_s", valid_z_s_keys, cat='Binary')
    z_year = LpVariable.dicts("z_y", valid_z_y_keys, cat='Binary')
    u = LpVariable.dicts("u", [(t, j) for t in years for j in crop_list], lowBound=0)
    v = LpVariable.dicts("v", [(t, j) for t in years for j in crop_list], lowBound=0)

    # --- 约束1：面积上限 ---
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s == 2:
                    continue
                keys_this = [(i, t, s, j) for j in crop_list if (i, t, s, j) in x]
                if keys_this:
                    model += lpSum(x[k] for k in keys_this) <= land_area[i]

    # --- 约束2：最小0.3亩 ---
    for key in valid_x_keys:
        i, t, s, j = key
        model += x[key] >= 0.3 * z_season[(i, t, s, j)]

    # --- 约束3：季转年 ---
    for i in lands:
        for t in years:
            for j in crop_list:
                z_s_list = []
                for s in seasons:
                    if (i, t, s, j) in z_season:
                        z_s_list.append(z_season[(i, t, s, j)])
                if z_s_list:
                    for zs in z_s_list:
                        model += z_year[(i, t, j)] >= zs
                    model += z_year[(i, t, j)] <= lpSum(z_s_list)
                else:
                    model += z_year[(i, t, j)] == 0

    # --- 约束4：重茬限制 ---
    # 4a：2024年与2023年同季重茬
    for i in lands:
        for s in seasons:
            for j in crop_list:
                if Hist[(i, s, j)] == 1 and (i, 2024, s, j) in x:
                    model += x[(i, 2024, s, j)] == 0

    # 4b：同季跨年重茬
    for i in lands:
        for s in seasons:
            for j in crop_list:
                for t in range(2025, 2031):
                    if (i, t, s, j) in z_season and (i, t-1, s, j) in z_season:
                        model += z_season[(i, t, s, j)] + z_season[(i, t-1, s, j)] <= 1

    # 4c：跨季重茬（相邻季次）
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s == 2:
                    continue
                for j in crop_list:
                    if t == 2024 and s == 1:
                        if (i, 2024, 1, j) in z_season and (i, 2023, 2, j) in z_season:
                            model += z_season[(i, 2024, 1, j)] + z_season[(i, 2023, 2, j)] <= 1
                    elif t > 2024:
                        prev_s = 2 if s == 1 else 1
                        prev_t = t - 1 if s == 1 else t
                        if (i, t, s, j) in z_season and (i, prev_t, prev_s, j) in z_season:
                            model += z_season[(i, t, s, j)] + z_season[(i, prev_t, prev_s, j)] <= 1

    # --- 约束5：连续三年豆类 ---
    for i in lands:
        for t_start in range(2024, 2029):
            model += lpSum(z_year[(i, t, j)] for t in range(t_start, t_start+3) for j in bean_crops) >= 1

    # --- 约束6：水浇地 ---
    for i in water_lands:
        for t in years:
            z_rice = lpSum(z_year[(i, t, j)] for j in rice_crops)
            z_veg = lpSum(z_season[(i, t, 1, j)] for j in first_season_veg if (i, t, 1, j) in z_season)
            model += z_rice + z_veg <= 1

            veg_area = lpSum(x[(i, t, 1, j)] for j in first_season_veg if (i, t, 1, j) in x)
            autumn_area = lpSum(x[(i, t, 2, j)] for j in autumn_veg if (i, t, 2, j) in x)
            model += autumn_area >= veg_area

    # --- 约束7：水浇地第二季最多一种秋冬菜 ---
    for i in water_lands:
        for t in years:
            model += lpSum(z_season[(i, t, 2, j)] for j in autumn_veg if (i, t, 2, j) in z_season) <= 1

    # --- 约束8：普通大棚第二季满种 ---
    for i in normal_greenhouse:
        for t in years:
            mushroom_area = lpSum(x[(i, t, 2, j)] for j in mushroom_crops if (i, t, 2, j) in x)
            model += mushroom_area >= 0.8 * land_area[i]

    # --- 约束9：产量拆分（使用Y_by_year） ---
    for t in years:
        for j in crop_list:
            y_terms = []
            for i in lands:
                for s in seasons:
                    if (i, t, s, j) in x:
                        y_terms.append(x[(i, t, s, j)] * Y_by_year[t].get((i, j), 0))
            if y_terms:
                total_y = lpSum(y_terms)
                model += u[(t, j)] + v[(t, j)] == total_y
                model += u[(t, j)] <= S_max_by_year[t].get(j, 1000)
            else:
                model += u[(t, j)] == 0
                model += v[(t, j)] == 0

    # --- 目标函数（使用P_by_year和C_by_year） ---
    revenue = lpSum(P_by_year[t].get(j, 2.0) * u[(t, j)] for t in years for j in crop_list)
    revenue += lpSum(0.5 * P_by_year[t].get(j, 2.0) * v[(t, j)] for t in years for j in crop_list)
    cost = lpSum(C_by_year[t].get((i, j), 0) * x[(i, t, s, j)] for (i, t, s, j) in valid_x_keys)
    model += revenue - cost

    return model, x, z_season, z_year, u, v


# --- 执行求解 ---
print("\\n开始求解鲁棒优化模型...")
model, x, zs, zy, u, v = build_robust_model()
solver = PULP_CBC_CMD(msg=False, timeLimit=1200)
model.solve(solver)

print(f"求解状态: {LpStatus[model.status]}")
print(f"最坏情景下7年总利润: {model.objective.value():.2f} 元")


def extract_results(model, x_var_dict):
    var_name_to_val = {v.name: v.varValue for v in model.variables() if v.varValue is not None}
    rec = []
    for key_tuple in x_var_dict:
        var_obj = x_var_dict[key_tuple]
        val = var_name_to_val.get(var_obj.name, 0.0)
        if val > 0.001:
            i, t, s, j = key_tuple
            rec.append({"地块名": i, "年份": t, "季次": s, "作物": j, "种植面积": round(val, 2)})
    return pd.DataFrame(rec)


def format_export(df, output_name):
    all_rows = []
    for i in lands:
        for s in seasons:
            if i in flat_lands and s == 2:
                continue
            all_rows.append(f"{i}_{'第一季' if s==1 else '第二季'}")
    with pd.ExcelWriter(output_name) as writer:
        for year in years:
            dfy = df[df["年份"] == year].copy()
            dfy["行标识"] = dfy.apply(lambda r: f"{r['地块名']}_{'第一季' if r['季次']==1 else '第二季'}", axis=1)
            if dfy.empty:
                pivot = pd.DataFrame(0, index=all_rows, columns=crop_list)
            else:
                pivot = dfy.pivot_table(index="行标识", columns="作物", values="种植面积", fill_value=0, aggfunc="sum")
                for c in crop_list:
                    if c not in pivot.columns:
                        pivot[c] = 0
                pivot = pivot.reindex(all_rows, fill_value=0)[crop_list]
            pivot.index.name = "季次"
            pivot.to_excel(writer, sheet_name=str(year))


df_robust = extract_results(model, x)
format_export(df_robust, "result2.xlsx")
print("✅ result2.xlsx 已生成")
print("="*60)
print("【模块4-2】完成！")