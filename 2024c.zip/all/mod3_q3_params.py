﻿"""
问题三模块1：构建交叉弹性矩阵 + 相关系数矩阵
输入：mod2_out.pkl（包含所有基础数据及 Allow/Hist）
输出：mod3_q3_out.pkl
"""

import pickle
import numpy as np

print("\\n" + "="*60)
print("【模块3-3】问题三：构建交叉弹性与相关系数矩阵")
print("="*60)

# ========== 1. 加载基础数据（从 mod2_out.pkl，包含 Allow 和 Hist） ==========
with open("mod2_out.pkl", "rb") as f:
    d = pickle.load(f)

# 提取所有需要的变量（mod2_out 已包含 mod1 的全部内容）
crop_list = d["crop_list"]
lands = d["lands"]
land_area = d["land_area"]
land_type = d["land_type"]
flat_lands = d["flat_lands"]
water_lands = d["water_lands"]
normal_greenhouse = d["normal_greenhouse"]
smart_greenhouse = d["smart_greenhouse"]
years = d["years"]
seasons = d["seasons"]
Allow = d["Allow"]          # 现在可以正常读取
Hist = d["Hist"]            # 现在可以正常读取
df_stats = d["df_stats"]

print(f"✅ 数据加载成功: {len(lands)}块地, {len(crop_list)}种作物")
print(f"   Allow 矩阵大小: {len(Allow)} 条记录")
print(f"   Hist 矩阵大小: {len(Hist)} 条记录")

# ========== 2. 作物分类 ==========
grain_crops = ['小麦', '玉米', '谷子', '高粱', '黍子', '荞麦', '南瓜', '红薯', '莜麦', '大麦']
rice_crops = ['水稻']
bean_crops = ['黄豆', '黑豆', '红豆', '绿豆', '爬豆', '豇豆', '刀豆', '芸豆']
mushroom_crops = ['榆黄菇', '香菇', '白灵菇', '羊肚菌']
autumn_veg = ['大白菜', '白萝卜', '红萝卜']
all_vegetable = [c for c in crop_list if c not in grain_crops and c not in rice_crops and c not in bean_crops and c not in mushroom_crops]
first_season_veg = [c for c in crop_list if c not in rice_crops and c not in autumn_veg and c not in mushroom_crops]

def get_crop_group(j):
    if j in bean_crops:
        return "豆类"
    elif j in grain_crops:
        return "粮食"
    elif j in rice_crops:
        return "水稻"
    elif j in mushroom_crops:
        return "食用菌"
    elif j in autumn_veg:
        return "秋冬菜"
    else:
        return "蔬菜"

print(f"作物分类完成:")
print(f"  豆类: {len(bean_crops)}种, 粮食: {len(grain_crops)}种")
print(f"  食用菌: {len(mushroom_crops)}种, 秋冬菜: {len(autumn_veg)}种")
print(f"  第一季蔬菜: {len(first_season_veg)}种")

# ========== 3. 构建交叉弹性矩阵 E ==========
n = len(crop_list)
E = np.eye(n) * (-1.0)

for idx, j in enumerate(crop_list):
    if j in bean_crops:
        E[idx, idx] = -1.2
    elif j in grain_crops:
        E[idx, idx] = -0.8
    elif j in rice_crops:
        E[idx, idx] = -0.7
    elif j in mushroom_crops:
        E[idx, idx] = -1.5
    elif j in autumn_veg:
        E[idx, idx] = -1.0
    else:
        E[idx, idx] = -1.0

# 同类作物之间为替代（正交叉弹性）
for i, j in enumerate(crop_list):
    group_i = get_crop_group(j)
    for k, l in enumerate(crop_list):
        if i == k:
            continue
        group_k = get_crop_group(l)
        if group_i == group_k:
            E[i, k] = 0.4
        elif (group_i in ["豆类", "蔬菜"] and group_k in ["豆类", "蔬菜"]):
            E[i, k] = 0.1
        elif group_i == "粮食" and group_k == "粮食":
            E[i, k] = 0.2
        else:
            E[i, k] = -0.05

print("✅ 交叉弹性矩阵构建完成")

# ========== 4. 构建相关系数矩阵 R ==========
R = np.eye(n) * 1.0

for i, j in enumerate(crop_list):
    group_i = get_crop_group(j)
    for k, l in enumerate(crop_list):
        if i >= k:
            continue
        group_k = get_crop_group(l)
        if group_i == group_k:
            R[i, k] = 0.7
        elif group_i in ["豆类", "蔬菜"] and group_k in ["豆类", "蔬菜"]:
            R[i, k] = 0.3
        elif group_i == "粮食" and group_k == "粮食":
            R[i, k] = 0.4
        else:
            R[i, k] = 0.1

for i in range(n):
    for k in range(i+1, n):
        R[k, i] = R[i, k]

print("✅ 相关系数矩阵构建完成")

# ========== 5. 保存（包含所有后续需要的变量） ==========
out_q3 = {
    # 地块信息
    "lands": lands,
    "land_area": land_area,
    "land_type": land_type,
    "flat_lands": flat_lands,
    "water_lands": water_lands,
    "normal_greenhouse": normal_greenhouse,
    "smart_greenhouse": smart_greenhouse,
    # 作物信息
    "crop_list": crop_list,
    "crop_group": {j: get_crop_group(j) for j in crop_list},
    # 作物分类（全部保存，避免后续缺失）
    "bean_crops": bean_crops,
    "grain_crops": grain_crops,
    "mushroom_crops": mushroom_crops,
    "autumn_veg": autumn_veg,
    "rice_crops": rice_crops,
    "first_season_veg": first_season_veg,
    "all_vegetable": all_vegetable,
    # 时间与约束
    "years": years,
    "seasons": seasons,
    "Allow": Allow,
    "Hist": Hist,
    "df_stats": df_stats,
    # 弹性与相关系数
    "E": E,
    "R": R,
}

with open("mod3_q3_out.pkl", "wb") as f:
    pickle.dump(out_q3, f)

print("✅ 模块3-3完成，输出 mod3_q3_out.pkl")
print(f"   包含变量: {list(out_q3.keys())}")