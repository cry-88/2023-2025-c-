﻿import pandas as pd
import pickle
import warnings
warnings.filterwarnings('ignore')

print("\n" + "="*60)
print("【模块1】数据读取与清洗")
print("="*60)

def clean_df_columns(df):
    df.columns = [str(col).strip() for col in df.columns]
    return df

# 读取原始Excel
df_land = pd.read_excel('附件1.xlsx', sheet_name='乡村的现有耕地')
df_crops = pd.read_excel('附件1.xlsx', sheet_name='乡村种植的农作物')
df_plant_2023 = pd.read_excel('附件2.xlsx', sheet_name='2023年的农作物种植情况')
df_stats = pd.read_excel('附件2.xlsx', sheet_name='2023年统计的相关数据')

# 统一清洗全部数据表列名
df_land = clean_df_columns(df_land)
df_crops = clean_df_columns(df_crops)
df_plant_2023 = clean_df_columns(df_plant_2023)
df_stats = clean_df_columns(df_stats)

print("df_stats列名：", df_stats.columns.tolist())

# =====================新增数据过滤=====================
# 清洗作物表：去掉空值、剔除(1)(2)(3)开头的说明行
df_crops = df_crops[df_crops["作物名称"].notna()]
df_crops = df_crops[~df_crops["作物名称"].astype(str).str.startswith(("(1)", "(2)", "(3)"))]

# 清洗2023种植记录表
df_plant_2023 = df_plant_2023[df_plant_2023["作物名称"].notna()]
df_plant_2023 = df_plant_2023[~df_plant_2023["作物名称"].astype(str).str.startswith(("(1)", "(2)", "(3)"))]
# =====================================================

# 地块基础信息
lands = df_land['地块名称'].tolist()
land_area = dict(zip(df_land['地块名称'], df_land['地块面积/亩']))
land_type_raw = df_land['地块类型'].astype(str).str.strip()
land_type = dict(zip(df_land['地块名称'], land_type_raw))

# 地块分类
flat_lands = [l for l in lands if land_type[l] in ['平旱地', '梯田', '山坡地']]
water_lands = [l for l in lands if land_type[l] == '水浇地']
normal_greenhouse = [l for l in lands if land_type[l] == '普通大棚']
smart_greenhouse = [l for l in lands if land_type[l] == '智慧大棚']

print(f"平旱/梯田/山坡地: {len(flat_lands)}块")
print(f"水浇地: {len(water_lands)}块")
print(f"普通大棚: {len(normal_greenhouse)}块")
print(f"智慧大棚: {len(smart_greenhouse)}块")

# 作物分类
crop_list = df_crops['作物名称'].tolist()
bean_crops = ['黄豆', '黑豆', '红豆', '绿豆', '爬豆', '豇豆', '刀豆', '芸豆']
mushroom_crops = ['榆黄菇', '香菇', '白灵菇', '羊肚菌']
autumn_veg = ['大白菜', '白萝卜', '红萝卜']
rice_crops = ['水稻']
first_season_veg = [c for c in crop_list if c not in rice_crops and c not in autumn_veg and c not in mushroom_crops]

years = list(range(2024, 2031))
seasons = [1, 2]
print(f"作物总数: {len(crop_list)}")
print(f"规划年份: {years}")

# 保存中间数据
save_data = {
    "lands": lands,
    "land_area": land_area,
    "land_type": land_type,
    "flat_lands": flat_lands,
    "water_lands": water_lands,
    "normal_greenhouse": normal_greenhouse,
    "smart_greenhouse": smart_greenhouse,
    "crop_list": crop_list,
    "bean_crops": bean_crops,
    "mushroom_crops": mushroom_crops,
    "autumn_veg": autumn_veg,
    "rice_crops": rice_crops,
    "first_season_veg": first_season_veg,
    "years": years,
    "seasons": seasons,
    "df_crops": df_crops,
    "df_plant_2023": df_plant_2023,
    "df_stats": df_stats
}

with open("mod1_out.pkl", "wb") as f:
    pickle.dump(save_data, f)

print("\n✅模块1完成，输出 mod1_out.pkl")