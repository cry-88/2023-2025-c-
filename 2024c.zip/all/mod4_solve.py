﻿import pickle
import pandas as pd
from pulp import *
import warnings
warnings.filterwarnings('ignore')

print("\\n" + "="*60)
print("【模块4】整数规划建模、求解、导出结果（修复版）")
print("="*60)

with open("mod3_out.pkl","rb") as f:
    d = pickle.load(f)

lands = d["lands"]
land_area = d["land_area"]
flat_lands = d["flat_lands"]
water_lands = d["water_lands"]
crop_list = d["crop_list"]
bean_crops = d["bean_crops"]
autumn_veg = d["autumn_veg"]
first_season_veg = d["first_season_veg"]
rice_crops = d["rice_crops"]
years = d["years"]
seasons = d["seasons"]
Allow = d["Allow"]
Hist = d["Hist"]
S_max_raw = d["S_max"]
df_stats = d["df_stats"]
land_type = d["land_type"]

# ========== 修复：手动补全缺失的变量 ==========
mushroom_crops = ['榆黄菇', '香菇', '白灵菇', '羊肚菌']   # mod1中定义的食用菌列表
normal_greenhouse = [i for i in lands if land_type[i] == "普通大棚"]
smart_greenhouse = [i for i in lands if land_type[i] == "智慧大棚"]

print(f"普通大棚: {len(normal_greenhouse)}个，智慧大棚: {len(smart_greenhouse)}个")

# ===== 修改点 1：修正 S_max（销量上限），乘以市场需求系数 0.7 =====
# 原因：原S_max来自2023年总产量，严重偏高，导致无滞销压力
MARKET_DEMAND_RATIO = 0.7        # 可调参数，根据题目描述“预期销售量”可设0.6~0.8
S_max = {j: S_max_raw[j] * MARKET_DEMAND_RATIO for j in S_max_raw}

print("\\n已应用市场需求系数 {:.1%}，调整后的 S_max 示例：".format(MARKET_DEMAND_RATIO))
for j in list(S_max.keys())[:5]:
    print(f"  {j}: {S_max[j]:.2f} (原值 {S_max_raw[j]:.2f})")

# ==========从df_stats现场构造 Y、C、P 字典（不变）==========
Y = dict()
C = dict()
P = dict()

df_stats.columns = [str(col).strip() for col in df_stats.columns]
for col in ["作物名称","地块类型","种植季次"]:
    if col in df_stats.columns:
        df_stats[col] = df_stats[col].astype(str).str.strip()

def parse_price(s):
    s = str(s).strip().replace("‑","-")
    if "-" in s:
        return float(s.split("-")[1].strip())
    else:
        return float(s)

for idx,row in df_stats.iterrows():
    j = row["作物名称"]
    ltype = row["地块类型"]
    yld = float(row["亩产量/斤"])
    cost = float(row["种植成本/(元/亩)"])
    price_high = parse_price(row["销售单价/(元/斤)"])
    for i in lands:
        if d["land_type"][i]==ltype:
            Y[(i,j)] = yld
            C[(i,j)] = cost
    if j not in P:
        P[j] = price_high

# 兜底（不变）
missing_crops = []
for j in crop_list:
    if j not in P:
        missing_crops.append(j)
        P[j] = 2.0
        for i in lands:
            Y.setdefault((i,j),0.0)
            C.setdefault((i,j),0.0)
if missing_crops:
    print(f"⚠️统计表缺失作物(已赋予默认值):{missing_crops}")


def build_model(scenario):
    model = LpProblem(f"Problem1_Scenario{scenario}", LpMaximize)
    valid_x_keys = []
    valid_z_s_keys = []
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s ==2:
                    continue
                for j in crop_list:
                    if Allow[(i,s,j)] ==1:
                        valid_x_keys.append((i,t,s,j))
                        valid_z_s_keys.append((i,t,s,j))
    valid_z_y_keys = [(i,t,j) for i in lands for t in years for j in crop_list]
    print(f"\\n场景{scenario} 有效x变量数: {len(valid_x_keys)}")
    print(f"场景{scenario} 有效z_season变量数: {len(valid_z_s_keys)}")

    x = LpVariable.dicts("x", valid_x_keys, lowBound=0, cat='Continuous')
    z_season = LpVariable.dicts("z_s", valid_z_s_keys, cat='Binary')
    z_year = LpVariable.dicts("z_y", valid_z_y_keys, cat='Binary')
    u = LpVariable.dicts("u", [(t,j) for t in years for j in crop_list], lowBound=0)
    v = LpVariable.dicts("v", [(t,j) for t in years for j in crop_list], lowBound=0)

    # --- 约束1：面积上限 ---
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s ==2:
                    continue
                keys_this = [(i,t,s,j) for j in crop_list if (i,t,s,j) in x]
                if keys_this:
                    model += lpSum(x[k] for k in keys_this) <= land_area[i]

    # --- 约束2：最小0.3亩 ---
    x_min = 0.3
    for key in valid_x_keys:
        i,t,s,j = key
        model += x[key] >= x_min * z_season[(i,t,s,j)]

    # --- 约束3：季标记转年度标记 ---
    for i in lands:
        for t in years:
            for j in crop_list:
                z_s_list = []
                for s in seasons:
                    if (i,t,s,j) in z_season:
                        z_s_list.append(z_season[(i,t,s,j)])
                if z_s_list:
                    for zs in z_s_list:
                        model += z_year[(i,t,j)] >= zs
                    model += z_year[(i,t,j)] <= lpSum(z_s_list)
                else:
                    model += z_year[(i,t,j)] == 0

    # --- 约束4：重茬限制 ---
    # 4a：2024年第一季不能与2023年同季重茬（原有）
    for i in lands:
        for s in seasons:
            for j in crop_list:
                if Hist[(i,s,j)] ==1 and (i,2024,s,j) in x:
                    model += x[(i,2024,s,j)] == 0

    # 4b：同季跨年不能重茬（原有）
    for i in lands:
        for s in seasons:
            for j in crop_list:
                for t in range(2025,2031):
                    if (i,t,s,j) in z_season and (i,t-1,s,j) in z_season:
                        model += z_season[(i,t,s,j)] + z_season[(i,t-1,s,j)] <= 1

    # ===== 修改点 2：增加跨季重茬约束（相邻季次不能种同种作物） =====
    for i in lands:
        for t in years:
            for s in seasons:
                if i in flat_lands and s == 2:   # 旱地只有第一季，无跨季
                    continue
                for j in crop_list:
                    # 处理2024年第一季 与 2023年第二季
                    if t == 2024 and s == 1:
                        if (i,2024,1,j) in z_season and (i,2023,2,j) in z_season:
                            model += z_season[(i,2024,1,j)] + z_season[(i,2023,2,j)] <= 1
                    # 其他年份：本季与上一季（t, s-1）比较
                    elif t > 2024:
                        prev_s = 2 if s == 1 else 1
                        prev_t = t - 1 if s == 1 else t
                        if (i,t,s,j) in z_season and (i,prev_t,prev_s,j) in z_season:
                            model += z_season[(i,t,s,j)] + z_season[(i,prev_t,prev_s,j)] <= 1

    # --- 约束5：连续三年必须种豆类 ---
    for i in lands:
        for t_start in range(2024,2029):
            model += lpSum(z_year[(i,t,j)] for t in range(t_start,t_start+3) for j in bean_crops) >= 1

    # --- 约束6：水浇地水稻/蔬菜二选一，以及第二季秋冬菜面积绑定 ---
    for i in water_lands:
        for t in years:
            z_rice = lpSum(z_year[(i,t,j)] for j in rice_crops)
            z_veg = lpSum(z_season[(i,t,1,j)] for j in first_season_veg if (i,t,1,j) in z_season)
            model += z_rice + z_veg <= 1

            # ===== 修改点 3：第二季秋冬菜面积 ≥ 第一季蔬菜面积 =====
            # 原先只用 autumn_z >= z_veg，现在改为面积约束
            veg_area = lpSum(x[(i,t,1,j)] for j in first_season_veg if (i,t,1,j) in x)
            autumn_area = lpSum(x[(i,t,2,j)] for j in autumn_veg if (i,t,2,j) in x)
            model += autumn_area >= veg_area

    # --- 约束7：水浇地第二季最多一种秋冬菜 ---
    for i in water_lands:
        for t in years:
            model += lpSum(z_season[(i,t,2,j)] for j in autumn_veg if (i,t,2,j) in z_season) <= 1

    # ===== 修改点 4：普通大棚第二季强制满种食用菌（至少80%） =====
    for i in normal_greenhouse:   # 普通大棚列表（需从d中获取，确保在全局有定义）
        for t in years:
            # 普通大棚第二季必须种植食用菌，且面积至少为地块面积的80%
            mushroom_area = lpSum(x[(i,t,2,j)] for j in mushroom_crops if (i,t,2,j) in x)
            model += mushroom_area >= 0.8 * land_area[i]

    # --- 约束8：产量 -> 正常销量 + 滞销量 ---
    for t in years:
        for j in crop_list:
            y_terms = []
            for i in lands:
                for s in seasons:
                    if (i,t,s,j) in x:
                        y_terms.append(x[(i,t,s,j)] * Y.get((i,j),0))
            if y_terms:
                total_y = lpSum(y_terms)
                model += u[(t,j)] + v[(t,j)] == total_y
                model += u[(t,j)] <= S_max[j]
            else:
                model += u[(t,j)] == 0
                model += v[(t,j)] == 0

    # --- 目标函数 ---
    revenue = lpSum(P[j]*u[(t,j)] for t in years for j in crop_list)
    if scenario ==2:
        revenue += lpSum(0.5*P[j]*v[(t,j)] for t in years for j in crop_list)
    cost = lpSum(C[(i,j)]*x[(i,t,s,j)] for (i,t,s,j) in valid_x_keys)
    model += revenue - cost
    return model,x,z_season,z_year,u,v


def extract_results_model(model, x_var_dict):
    var_name_to_val = {}
    for v in model.variables():
        if v.varValue is not None:
            var_name_to_val[v.name] = v.varValue
    rec = []
    for key_tuple in x_var_dict:
        var_obj = x_var_dict[key_tuple]
        val = var_name_to_val.get(var_obj.name, 0.0)
        if val > 0.001:
            i,t,s,j = key_tuple
            rec.append({"地块名":i,"年份":t,"季次":s,"作物":j,"种植面积":round(val,2)})
    return pd.DataFrame(rec)


def format_export(df, output_name):
    all_rows = []
    for i in lands:
        for s in seasons:
            if i in flat_lands and s ==2:
                continue
            all_rows.append(f"{i}_{'第一季' if s==1 else '第二季'}")
    with pd.ExcelWriter(output_name) as writer:
        for year in years:
            dfy = df[df["年份"]==year].copy()
            dfy["行标识"] = dfy.apply(lambda r: f"{r['地块名']}_{'第一季' if r['季次']==1 else '第二季'}",axis=1)
            if dfy.empty:
                pivot = pd.DataFrame(0,index=all_rows,columns=crop_list)
            else:
                pivot = dfy.pivot_table(index="行标识",columns="作物",values="种植面积",fill_value=0,aggfunc="sum")
                for c in crop_list:
                    if c not in pivot.columns:
                        pivot[c]=0
                pivot = pivot.reindex(all_rows,fill_value=0)[crop_list]
            pivot.index.name = "季次"
            pivot.to_excel(writer,sheet_name=str(year))


# 求解场景1
print("\\n==================== 场景1：滞销无收益 ====================")
model1,x1,zs1,zy1,u1,v1 = build_model(1)
solver1 = PULP_CBC_CMD(msg=False, timeLimit=1200)
model1.solve(solver1)
print(f"model1求解状态代码：{model1.status}, {LpStatus[model1.status]}")
obj1 = model1.objective.value()
df1 = extract_results_model(model1, x1)
format_export(df1,"result1_1.xlsx")
print(f"求解状态:{LpStatus[model1.status]} 7年总利润:{obj1:.2f}元")
print("result1_1.xlsx 已生成")

# 求解场景2
print("\\n==================== 场景2：滞销半价 ====================")
model2,x2,zs2,zy2,u2,v2 = build_model(2)
solver2 = PULP_CBC_CMD(msg=False, timeLimit=1200)
model2.solve(solver2)
print(f"model2求解状态代码：{model2.status}, {LpStatus[model2.status]}")
obj2 = model2.objective.value()
df2 = extract_results_model(model2, x2)
format_export(df2,"result1_2.xlsx")
print(f"求解状态:{LpStatus[model2.status]} 7年总利润:{obj2:.2f}元")
print("result1_2.xlsx 已生成")

print("\\n==================== 结果对比 ====================")
print(f"场景1总利润：{obj1:.2f} 元")
print(f"场景2总利润：{obj2:.2f} 元")
print(f"利润差值：{obj2-obj1:.2f} 元")
print("✅全部计算完成！")