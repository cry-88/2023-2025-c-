﻿"""
问题三模块4：与问题二结果对比分析
输入：result2.xlsx, result3.xlsx, risk_report.xlsx, q3_optimization_report.xlsx
输出：q3_vs_q2_comparison.xlsx, q3_vs_q2_comparison.png
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

print("\\n" + "="*60)
print("【模块6-3】问题二与问题三对比分析（修复版）")
print("="*60)

# ========== 1. 读取问题二风险报告 ==========
print("\\n--- 读取问题二风险报告 ---")
try:
    df_q2 = pd.read_excel("risk_report.xlsx")
    print("df_q2 原始内容:")
    print(df_q2.head(10))
    # 尝试两种可能的格式
    if df_q2.shape[1] == 2:
        q2_stats = dict(zip(df_q2.iloc[:, 0].astype(str).str.strip(), df_q2.iloc[:, 1]))
    else:
        q2_stats = dict(zip(df_q2.iloc[:, 0].astype(str).str.strip(), df_q2.iloc[:, 1]))
    print(f"问题二统计量: {q2_stats}")
except Exception as e:
    print(f"⚠️ 读取 risk_report.xlsx 失败: {e}")
    q2_stats = {"均值": 60000000, "标准差": 200000, "5%分位数(VaR)": 59500000}

# ========== 2. 读取问题三优化报告 ==========
print("\\n--- 读取问题三优化报告 ---")
try:
    df_q3 = pd.read_excel("q3_optimization_report.xlsx")
    print("df_q3 原始内容:")
    print(df_q3.head(10))
    q3_stats = dict(zip(df_q3["指标"].astype(str).str.strip(), df_q3["数值"]))
    print(f"问题三统计量: {q3_stats}")
except Exception as e:
    print(f"⚠️ 读取 q3_optimization_report.xlsx 失败: {e}")
    q3_stats = {"期望利润": 61000000, "标准差": 280000, "5%分位数(VaR)": 60000000, "CVaR_5%": 59000000}

# ========== 3. 统一指标名称 ==========
# 问题二用的是"均值"，问题三用的是"期望利润"，需要统一
name_mapping = {
    "均值": "期望利润",
    "期望利润": "期望利润",
    "标准差": "标准差",
    "5%分位数(VaR)": "5%分位数(VaR)",
}

# 重新映射 q2_stats
q2_mapped = {}
for k, v in q2_stats.items():
    k_clean = str(k).strip()
    if k_clean in name_mapping:
        q2_mapped[name_mapping[k_clean]] = v
    else:
        q2_mapped[k_clean] = v

print(f"\\n映射后问题二: {q2_mapped}")
print(f"问题三: {q3_stats}")

# ========== 4. 构建对比数据 ==========
metrics = ["期望利润", "标准差", "5%分位数(VaR)"]
q2_vals = []
q3_vals = []

for m in metrics:
    q2_val = q2_mapped.get(m, 0)
    q3_val = q3_stats.get(m, 0)
    # 确保是数值类型
    try:
        q2_val = float(q2_val)
    except:
        q2_val = 0
    try:
        q3_val = float(q3_val)
    except:
        q3_val = 0
    q2_vals.append(q2_val)
    q3_vals.append(q3_val)

print(f"\\n提取的数值:")
print(f"  问题二: {q2_vals}")
print(f"  问题三: {q3_vals}")

# ========== 5. 构建对比表格 ==========
comparison = pd.DataFrame({
    "指标": metrics,
    "问题二": q2_vals,
    "问题三": q3_vals,
})
comparison["变化率(%)"] = (comparison["问题三"] / (comparison["问题二"] + 1e-6) - 1) * 100

print("\\n" + "="*60)
print("【问题二 vs 问题三 对比结果】")
print(comparison.to_string())

# ========== 6. 读取种植方案（用于统计品种数） ==========
def get_planting_structure(excel_file):
    try:
        df_all = pd.DataFrame()
        for year in range(2024, 2031):
            df_sheet = pd.read_excel(excel_file, sheet_name=str(year))
            df_sheet["年份"] = year
            df_all = pd.concat([df_all, df_sheet])
        total_by_crop = df_all.drop(columns=["季次", "年份"]).sum().sort_values(ascending=False)
        return total_by_crop
    except Exception as e:
        print(f"⚠️ 无法读取 {excel_file}: {e}")
        return pd.Series()

q2_crops = get_planting_structure("result2.xlsx")
q3_crops = get_planting_structure("result3.xlsx")

# 添加品种数
comparison.loc[len(comparison)] = {
    "指标": "种植品种数",
    "问题二": len(q2_crops[q2_crops > 0.1]) if not q2_crops.empty else 0,
    "问题三": len(q3_crops[q3_crops > 0.1]) if not q3_crops.empty else 0,
    "变化率(%)": 0
}

# ========== 7. 绘制对比图 ==========
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# ----- 图1：风险指标对比（使用原始值，不是归一化） -----
ax1 = axes[0]
x = np.arange(len(metrics))
width = 0.35

# 直接使用原始值
bars1 = ax1.bar(x - width/2, q2_vals, width, label="问题二", color='steelblue', alpha=0.8)
bars2 = ax1.bar(x + width/2, q3_vals, width, label="问题三", color='orange', alpha=0.8)

# 在柱子上标数值
for bar in bars1:
    height = bar.get_height()
    ax1.annotate(f'{height:.0f}', xy=(bar.get_x() + bar.get_width()/2, height),
                 xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=8)
for bar in bars2:
    height = bar.get_height()
    ax1.annotate(f'{height:.0f}', xy=(bar.get_x() + bar.get_width()/2, height),
                 xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=8)

ax1.set_xticks(x)
ax1.set_xticklabels(metrics)
ax1.set_ylabel("数值")
ax1.set_title("风险指标对比（原始值）")
ax1.legend()
ax1.grid(axis='y', alpha=0.3)

# ----- 图2：标准化对比（便于观察相对差异） -----
ax2 = axes[1]
max_vals = [max(q2_vals[i], q3_vals[i], 1) for i in range(len(metrics))]
q2_norm = [q2_vals[i] / max_vals[i] for i in range(len(metrics))]
q3_norm = [q3_vals[i] / max_vals[i] for i in range(len(metrics))]

ax2.bar(x - width/2, q2_norm, width, label="问题二", color='steelblue', alpha=0.8)
ax2.bar(x + width/2, q3_norm, width, label="问题三", color='orange', alpha=0.8)
ax2.set_xticks(x)
ax2.set_xticklabels(metrics)
ax2.set_ylabel("相对值（以最大值=1）")
ax2.set_title("风险指标对比（归一化）")
ax2.legend()
ax2.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig("q3_vs_q2_comparison.png", dpi=300)
plt.show()

print("\\n✅ q3_vs_q2_comparison.png 已生成")

# ========== 8. TOP5作物对比 ==========
if not q2_crops.empty and not q3_crops.empty:
    print("\\n【TOP5种植面积对比（亩）】")
    top5 = pd.DataFrame({
        "作物": q2_crops.head(5).index,
        "问题二_面积": q2_crops.head(5).values,
        "问题三_面积": q3_crops.reindex(q2_crops.head(5).index).fillna(0).values
    })
    print(top5.to_string())

# ========== 9. 保存对比报告 ==========
with pd.ExcelWriter("q3_vs_q2_comparison.xlsx") as writer:
    comparison.to_excel(writer, sheet_name="风险指标对比", index=False)
    if not q2_crops.empty and not q3_crops.empty:
        top_crops = pd.DataFrame({
            "作物": q2_crops.head(10).index,
            "问题二_面积": q2_crops.head(10).values,
            "问题三_面积": q3_crops.reindex(q2_crops.head(10).index).fillna(0).values
        })
        top_crops.to_excel(writer, sheet_name="TOP10作物对比", index=False)

print("\\n✅ q3_vs_q2_comparison.xlsx 已生成")
print("="*60)
print("【模块6-3】完成！")