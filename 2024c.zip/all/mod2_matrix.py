﻿import pickle

print("\n" + "="*60)
print("【模块2】构建Allow允许种植矩阵、Hist重茬矩阵")
print("="*60)

with open("mod1_out.pkl", "rb") as f:
    d = pickle.load(f)

lands = d["lands"]
flat_lands = d["flat_lands"]
water_lands = d["water_lands"]
normal_greenhouse = d["normal_greenhouse"]
smart_greenhouse = d["smart_greenhouse"]
crop_list = d["crop_list"]
autumn_veg = d["autumn_veg"]
mushroom_crops = d["mushroom_crops"]
rice_crops = d["rice_crops"]
df_crops = d["df_crops"]
df_plant_2023 = d["df_plant_2023"]
seasons = d["seasons"]

# =========新增构建 land_type 字典=========
land_type = {}
for i in flat_lands:
    land_type[i] = "平旱地"
for i in water_lands:
    land_type[i] = "水浇地"
for i in normal_greenhouse:
    land_type[i] = "普通大棚"
for i in smart_greenhouse:
    land_type[i] = "智慧大棚"

# 预构建作物 -> 种植耕地映射，去除空格换行
crop_plant_land = {}
for _,row in df_crops.iterrows():
    c = row["作物名称"]
    pl = str(row["种植耕地"]).replace(" ","").replace("\n","").replace("\r","")
    crop_plant_land[c] = pl

Allow = {(i, s, j): 0 for i in lands for s in seasons for j in crop_list}

for i in lands:
    for s in seasons:
        for j in crop_list:
            plant_land = crop_plant_land.get(j, "")
            if not plant_land:
                continue

            if i in flat_lands:
                #平旱地、梯田、山坡地：仅s=1，水稻除外
                if s == 1 and ('平旱地' in plant_land or '梯田' in plant_land or '山坡地' in plant_land):
                    if j not in rice_crops:
                        Allow[(i, s, j)] = 1

            elif i in water_lands:
                if s == 1:
                    #第一季：水稻 / 普通蔬菜（非秋三菜、非菌菇）
                    if '水浇地' in plant_land:
                        if (j in rice_crops) or (j not in autumn_veg and j not in mushroom_crops):
                            Allow[(i, s, j)] = 1
                else:
                    #第二季：只能大白菜、白萝卜、红萝卜
                    if '水浇地' in plant_land and j in autumn_veg:
                        Allow[(i, s, j)] = 1

            elif i in normal_greenhouse:
                if s == 1:
                    #普通大棚第一季：蔬菜，排除秋三菜、菌菇
                    if '普通大棚' in plant_land and j not in autumn_veg and j not in mushroom_crops:
                        Allow[(i, s, j)] = 1
                else:
                    #普通大棚第二季：仅食用菌
                    if '普通大棚' in plant_land and j in mushroom_crops:
                        Allow[(i, s, j)] = 1

            elif i in smart_greenhouse:
                #智慧大棚两季均可；禁止水稻、秋三菜、菌菇
                if '智慧大棚' in plant_land and j not in rice_crops and j not in autumn_veg and j not in mushroom_crops:
                    Allow[(i, s, j)] = 1

#校验输出
print("\n====地块适配校验====")
for i in lands:
    allow_count = sum(1 for s in seasons for j in crop_list if Allow[(i, s, j)] == 1)
    if allow_count == 0:
        print(f"警告：地块 {i} 无允许种植作物！")

e1_s1 = sum(1 for j in crop_list if Allow[("E1", 1, j)] == 1)
e1_s2 = sum(1 for j in crop_list if Allow[("E1", 2, j)] == 1)
print(f"E1普通大棚 第一季可种:{e1_s1}种 第二季可种:{e1_s2}种")

# Hist重茬矩阵：2023年种植记录
Hist = {(i, s, j):0 for i in lands for s in seasons for j in crop_list}
for _,row in df_plant_2023.iterrows():
    i = row['种植地块']
    j = row['作物名称']
    season = row['种植季次']
    if season == '单季' or season == '第一季':
        Hist[(i,1,j)] = 1
    elif season == '第二季':
        Hist[(i,2,j)] = 1

out2 = {
    **d,
    "land_type": land_type,
    "Allow":Allow,
    "Hist":Hist
}
with open("mod2_out.pkl","wb") as f:
    pickle.dump(out2,f)

print("\n✅模块2完成，输出 mod2_out.pkl")