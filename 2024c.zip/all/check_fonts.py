﻿import matplotlib.font_manager as fm

# 获取系统所有字体
font_list = fm.fontManager.ttflist

# 筛选包含中文关键词的字体
chinese_fonts = []
for f in font_list:
    name = f.name
    # 常见的支持中文的字体关键词
    keywords = ['SimHei', 'Microsoft YaHei', 'MS Gothic', 'SimSun', 'FangSong', 
                'KaiTi', 'PingFang', 'Hei', 'Song', 'YaHei', 'Arial Unicode']
    if any(k in name for k in keywords):
        chinese_fonts.append(name)

# 去重并排序
chinese_fonts = sorted(set(chinese_fonts))

print("="*60)
print("【系统可用的中文字体】")
print("="*60)
for i, f in enumerate(chinese_fonts, 1):
    print(f"{i}. {f}")

print("\\\\n" + "="*60)
print("【所有支持中文的字体路径】")
print("="*60)
for f in font_list:
    if any(k in f.name for k in ['SimHei', 'YaHei', 'Arial Unicode']):
        print(f"{f.name}: {f.fname}")